module Demo_JDBC1 {
	exports com.ecommerce;

	requires java.sql;
}