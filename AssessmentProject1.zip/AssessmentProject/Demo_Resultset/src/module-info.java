module Demo_JDBC3 {
	requires java.sql;
}