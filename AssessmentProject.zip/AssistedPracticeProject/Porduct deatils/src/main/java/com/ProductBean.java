package com;

public class ProductBean {
	int cid;
	String name;
	Double Price;
	public int getcid() {
		return cid;
	}
	public void setcid(int pid) {
		cid = pid;
	}
	public String getname() {
		return name;
	}
	public void setname(String pname) {
		name = pname;
	}
	public Double getPrice() {
		return Price;
	}
	public void setPrice(Double price) {
		Price = price;
	}
	
	
}

